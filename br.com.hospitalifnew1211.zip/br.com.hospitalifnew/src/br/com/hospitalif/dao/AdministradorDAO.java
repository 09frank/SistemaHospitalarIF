/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * 
 */
package br.com.hospitalif.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import br.com.hospitalif.conexao.Conexao;
import br.com.hospitalif.model.Administrador;

public class AdministradorDAO {

	/// � apenas um Bot�o de Cadastro de Funcionario.
	public void create(Administrador a) {
		Conexao conn = new Conexao();
		Connection conexao = conn.getConnection();
		System.out.println(conn.getStatus());
		String sqlInsere = "INSERT INTO tb_atendimento VALUES (?,?,?,?,?) ";
		PreparedStatement stmt = null;
		try {
			stmt = conexao.prepareStatement(sqlInsere);
		} catch (SQLException e6) {
			// TODO Auto-generated catch block
			e6.printStackTrace();
		}
		try {
			stmt.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
