/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * 
 */
package br.com.hospitalif.rascunho;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import br.com.hospitalif.conexao.Conexao;

/**
 * @author Frank
 *
 */
public class AdministradorDAO {

	public void create(Administrador enf) throws SQLException {
		Conexao conn = new Conexao();
		Connection conexao = conn.getConnection();
		System.out.println(conn.getStatus());
		String sqlInsere = "INSERT INTO tb_administrador VALUES (?,?,?) ";
		PreparedStatement stmt = conexao.prepareStatement(sqlInsere);

		stmt.execute();
	}
	

}
