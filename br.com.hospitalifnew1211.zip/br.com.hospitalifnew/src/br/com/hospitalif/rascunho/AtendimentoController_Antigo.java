/**
 * Sample Skeleton for 'Atendimento.fxml' Controller Class
 */

package br.com.hospitalif.rascunho;

import java.awt.TextField;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

//import br.com.hospitalif.dao.AtendimentoDAO;
//import br.com.hospitalif.model.Atendimento;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;

public class AtendimentoController {

	@FXML // ResourceBundle that was given to the FXMLLoader
	private ResourceBundle resources;

	@FXML // URL location of the FXML file that was given to the FXMLLoader
	private URL location;

	@FXML // fx:id="txtAtendimento"
	private TextField txtAtendimento; // Value injected by FXMLLoader

	@FXML // fx:id="txtAtendimento0"
	private TextField txtAtendimento0; // Value injected by FXMLLoader

	@FXML // fx:id="txtAtendimento1"
	private TextField txtAtendimento1; // Value injected by FXMLLoader

	@FXML // fx:id="txtAtendimento2"
	private TextArea txtAtendimento2; // Value injected by FXMLLoader

	@FXML // fx:id="txtAtendimento3"
	private TextArea txtAtendimento3; // Value injected by FXMLLoader

	@FXML // fx:id="txtAtendimento7"
	private Button txtAtendimento7; // Value injected by FXMLLoader

	@FXML // fx:id="txtAtendimento4"
	private TableView<?> txtAtendimento4; // Value injected by FXMLLoader

	@FXML // fx:id="txtAtendimento5"
	private TableColumn<?, ?> txtAtendimento5; // Value injected by FXMLLoader

	@FXML // fx:id="txtAtendimento6"
	private TableColumn<?, ?> txtAtendimento6; // Value injected by FXMLLoader

	@FXML
    void handleSubmitButtonAction(ActionEvent event) throws IOException{
/*
    	if (txtAtendimento7.getText().equals("")) {
			Stage stage = (Stage) txtAtendimento7.getScene().getWindow();
			Parent root = FXMLLoader.load(getClass().getResource("../view/Atendimento.fxml"));
			Scene scene = new Scene(root);
			// scene.getStylesheets().add(getClass().getResource("/css/estilo.css").
			// toExternalForm()); stage.setTitle("Alerta: ERRO!"); stage.setScene(scene);
			stage.show();
		} else {
			Atendimento en = new Atendimento();
			en.setAltura(Float.parseFloat((String) (txtAtendimento0.getText())));
			en.setPeso(Float.parseFloat((String) (txtAtendimento.getText())));
			en.setComentarioEnfermeiro(txtAtendimento2.getText());
			en.setComentarioMedico(txtAtendimento3.getText());

			// en.setData(Date.parseDate()String(txtAtendimento1.getDate())));

			AtendimentoDAO efdaoe = new AtendimentoDAO();
			efdaoe.inserir(en);

			Stage stage = (Stage) txtAtendimento7.getScene().getWindow();
			Parent root = FXMLLoader.load(getClass().getResource("../view/Atendimento.fxml"));
			Scene scene = new Scene(root);
			// scene.getStylesheets().add(getClass().getResource("/css/estilo.css").
			// toExternalForm()); stage.setTitle("Alerta: Sucesso!"); stage.setScene(scene);
			stage.show();
		}*/

    	
    }

	@FXML // This method is called by the FXMLLoader when initialization is complete
	void initialize() {
		assert txtAtendimento != null : "fx:id=\"txtAtendimento\" was not injected: check your FXML file 'Atendimento.fxml'.";
		assert txtAtendimento0 != null : "fx:id=\"txtAtendimento0\" was not injected: check your FXML file 'Atendimento.fxml'.";
		assert txtAtendimento1 != null : "fx:id=\"txtAtendimento1\" was not injected: check your FXML file 'Atendimento.fxml'.";
		assert txtAtendimento2 != null : "fx:id=\"txtAtendimento2\" was not injected: check your FXML file 'Atendimento.fxml'.";
		assert txtAtendimento3 != null : "fx:id=\"txtAtendimento3\" was not injected: check your FXML file 'Atendimento.fxml'.";
		assert txtAtendimento7 != null : "fx:id=\"txtAtendimento7\" was not injected: check your FXML file 'Atendimento.fxml'.";
		assert txtAtendimento4 != null : "fx:id=\"txtAtendimento4\" was not injected: check your FXML file 'Atendimento.fxml'.";
		assert txtAtendimento5 != null : "fx:id=\"txtAtendimento5\" was not injected: check your FXML file 'Atendimento.fxml'.";
		assert txtAtendimento6 != null : "fx:id=\"txtAtendimento6\" was not injected: check your FXML file 'Atendimento.fxml'.";

	}
}


//____________________________________________________________

/**
 * Sample Skeleton for 'Atendimento.fxml' Controller Class
 */

package br.com.hospitalif.rascunho;

import java.awt.TextField;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

//import br.com.hospitalif.dao.AtendimentoDAO;
//import br.com.hospitalif.model.Atendimento;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;

public class AtendimentoController {

	@FXML // ResourceBundle that was given to the FXMLLoader
	private ResourceBundle resources;

	@FXML // URL location of the FXML file that was given to the FXMLLoader
	private URL location;

	@FXML // fx:id="txtAtendimento"
	private TextField txtAtendimento; // Value injected by FXMLLoader

	@FXML // fx:id="txtAtendimento0"
	private TextField txtAtendimento0; // Value injected by FXMLLoader

	@FXML // fx:id="txtAtendimento1"
	private TextField txtAtendimento1; // Value injected by FXMLLoader

	@FXML // fx:id="txtAtendimento2"
	private TextArea txtAtendimento2; // Value injected by FXMLLoader

	@FXML // fx:id="txtAtendimento3"
	private TextArea txtAtendimento3; // Value injected by FXMLLoader

	@FXML // fx:id="txtAtendimento7"
	private Button txtAtendimento7; // Value injected by FXMLLoader

	@FXML // fx:id="txtAtendimento4"
	private TableView<?> txtAtendimento4; // Value injected by FXMLLoader

	@FXML // fx:id="txtAtendimento5"
	private TableColumn<?, ?> txtAtendimento5; // Value injected by FXMLLoader

	@FXML // fx:id="txtAtendimento6"
	private TableColumn<?, ?> txtAtendimento6; // Value injected by FXMLLoader

	@FXML
    void handleSubmitButtonAction(ActionEvent event) throws IOException{
/*
    	if (txtAtendimento7.getText().equals("")) {
			Stage stage = (Stage) txtAtendimento7.getScene().getWindow();
			Parent root = FXMLLoader.load(getClass().getResource("../view/Atendimento.fxml"));
			Scene scene = new Scene(root);
			// scene.getStylesheets().add(getClass().getResource("/css/estilo.css").
			// toExternalForm()); stage.setTitle("Alerta: ERRO!"); stage.setScene(scene);
			stage.show();
		} else {
			Atendimento en = new Atendimento();
			en.setAltura(Float.parseFloat((String) (txtAtendimento0.getText())));
			en.setPeso(Float.parseFloat((String) (txtAtendimento.getText())));
			en.setComentarioEnfermeiro(txtAtendimento2.getText());
			en.setComentarioMedico(txtAtendimento3.getText());

			// en.setData(Date.parseDate()String(txtAtendimento1.getDate())));

			AtendimentoDAO efdaoe = new AtendimentoDAO();
			efdaoe.inserir(en);

			Stage stage = (Stage) txtAtendimento7.getScene().getWindow();
			Parent root = FXMLLoader.load(getClass().getResource("../view/Atendimento.fxml"));
			Scene scene = new Scene(root);
			// scene.getStylesheets().add(getClass().getResource("/css/estilo.css").
			// toExternalForm()); stage.setTitle("Alerta: Sucesso!"); stage.setScene(scene);
			stage.show();
		}*/

    	
    }

	@FXML // This method is called by the FXMLLoader when initialization is complete
	void initialize() {
		assert txtAtendimento != null : "fx:id=\"txtAtendimento\" was not injected: check your FXML file 'Atendimento.fxml'.";
		assert txtAtendimento0 != null : "fx:id=\"txtAtendimento0\" was not injected: check your FXML file 'Atendimento.fxml'.";
		assert txtAtendimento1 != null : "fx:id=\"txtAtendimento1\" was not injected: check your FXML file 'Atendimento.fxml'.";
		assert txtAtendimento2 != null : "fx:id=\"txtAtendimento2\" was not injected: check your FXML file 'Atendimento.fxml'.";
		assert txtAtendimento3 != null : "fx:id=\"txtAtendimento3\" was not injected: check your FXML file 'Atendimento.fxml'.";
		assert txtAtendimento7 != null : "fx:id=\"txtAtendimento7\" was not injected: check your FXML file 'Atendimento.fxml'.";
		assert txtAtendimento4 != null : "fx:id=\"txtAtendimento4\" was not injected: check your FXML file 'Atendimento.fxml'.";
		assert txtAtendimento5 != null : "fx:id=\"txtAtendimento5\" was not injected: check your FXML file 'Atendimento.fxml'.";
		assert txtAtendimento6 != null : "fx:id=\"txtAtendimento6\" was not injected: check your FXML file 'Atendimento.fxml'.";

	}
}
//__________________-
/**
 * Sample Skeleton for 'Atendimento.fxml' Controller Class
 */

package br.com.hospitalif.rascunho;

import java.awt.TextField;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

//import br.com.hospitalif.dao.AtendimentoDAO;
//import br.com.hospitalif.model.Atendimento;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;

public class AtendimentoController {

	@FXML // ResourceBundle that was given to the FXMLLoader
	private ResourceBundle resources;

	@FXML // URL location of the FXML file that was given to the FXMLLoader
	private URL location;

	@FXML // fx:id="txtAtendimento"
	private TextField txtAtendimento; // Value injected by FXMLLoader

	@FXML // fx:id="txtAtendimento0"
	private TextField txtAtendimento0; // Value injected by FXMLLoader

	@FXML // fx:id="txtAtendimento1"
	private TextField txtAtendimento1; // Value injected by FXMLLoader

	@FXML // fx:id="txtAtendimento2"
	private TextArea txtAtendimento2; // Value injected by FXMLLoader

	@FXML // fx:id="txtAtendimento3"
	private TextArea txtAtendimento3; // Value injected by FXMLLoader

	@FXML // fx:id="txtAtendimento7"
	private Button txtAtendimento7; // Value injected by FXMLLoader

	@FXML // fx:id="txtAtendimento4"
	private TableView<?> txtAtendimento4; // Value injected by FXMLLoader

	@FXML // fx:id="txtAtendimento5"
	private TableColumn<?, ?> txtAtendimento5; // Value injected by FXMLLoader

	@FXML // fx:id="txtAtendimento6"
	private TableColumn<?, ?> txtAtendimento6; // Value injected by FXMLLoader

	@FXML
    void handleSubmitButtonAction(ActionEvent event) throws IOException{
/*
    	if (txtAtendimento7.getText().equals("")) {
			Stage stage = (Stage) txtAtendimento7.getScene().getWindow();
			Parent root = FXMLLoader.load(getClass().getResource("../view/Atendimento.fxml"));
			Scene scene = new Scene(root);
			// scene.getStylesheets().add(getClass().getResource("/css/estilo.css").
			// toExternalForm()); stage.setTitle("Alerta: ERRO!"); stage.setScene(scene);
			stage.show();
		} else {
			Atendimento en = new Atendimento();
			en.setAltura(Float.parseFloat((String) (txtAtendimento0.getText())));
			en.setPeso(Float.parseFloat((String) (txtAtendimento.getText())));
			en.setComentarioEnfermeiro(txtAtendimento2.getText());
			en.setComentarioMedico(txtAtendimento3.getText());

			// en.setData(Date.parseDate()String(txtAtendimento1.getDate())));

			AtendimentoDAO efdaoe = new AtendimentoDAO();
			efdaoe.inserir(en);

			Stage stage = (Stage) txtAtendimento7.getScene().getWindow();
			Parent root = FXMLLoader.load(getClass().getResource("../view/Atendimento.fxml"));
			Scene scene = new Scene(root);
			// scene.getStylesheets().add(getClass().getResource("/css/estilo.css").
			// toExternalForm()); stage.setTitle("Alerta: Sucesso!"); stage.setScene(scene);
			stage.show();
		}*/

    	
    }

	@FXML // This method is called by the FXMLLoader when initialization is complete
	void initialize() {
		assert txtAtendimento != null : "fx:id=\"txtAtendimento\" was not injected: check your FXML file 'Atendimento.fxml'.";
		assert txtAtendimento0 != null : "fx:id=\"txtAtendimento0\" was not injected: check your FXML file 'Atendimento.fxml'.";
		assert txtAtendimento1 != null : "fx:id=\"txtAtendimento1\" was not injected: check your FXML file 'Atendimento.fxml'.";
		assert txtAtendimento2 != null : "fx:id=\"txtAtendimento2\" was not injected: check your FXML file 'Atendimento.fxml'.";
		assert txtAtendimento3 != null : "fx:id=\"txtAtendimento3\" was not injected: check your FXML file 'Atendimento.fxml'.";
		assert txtAtendimento7 != null : "fx:id=\"txtAtendimento7\" was not injected: check your FXML file 'Atendimento.fxml'.";
		assert txtAtendimento4 != null : "fx:id=\"txtAtendimento4\" was not injected: check your FXML file 'Atendimento.fxml'.";
		assert txtAtendimento5 != null : "fx:id=\"txtAtendimento5\" was not injected: check your FXML file 'Atendimento.fxml'.";
		assert txtAtendimento6 != null : "fx:id=\"txtAtendimento6\" was not injected: check your FXML file 'Atendimento.fxml'.";

	}
}
