/**
 * Sample Skeleton for 'Paciente.fxml' Controller Class
 */

package br.com.hospitalif.controller;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

public class PacienteController {

	@FXML // ResourceBundle that was given to the FXMLLoader
	private ResourceBundle resources;

	@FXML // URL location of the FXML file that was given to the FXMLLoader
	private URL location;

	@FXML // fx:id="btnCadastrar9"
	private Button btnOk; // Value injected by FXMLLoader

	@FXML // fx:id="tabPaciente"
	private TableView<?> tabNome; // Value injected by FXMLLoader

	@FXML // fx:id="tabPaciente0"
	private TableColumn<?, ?> tabComentario; // Value injected by FXMLLoader

	@FXML // fx:id="tabPaciente1"
	private TableColumn<?, ?> tabNomeHistorico; // Value injected by FXMLLoader

	@FXML // fx:id="tabPaciente2"
	private TableView<?> tabData; // Value injected by FXMLLoader

	@FXML // fx:id="tabPaciente3"
	private TableColumn<?, ?> tabStatusEnfermidade; // Value injected by FXMLLoader

	@FXML // fx:id="tabPaciente4"
	private TableColumn<?, ?> tabDataSaida; // Value injected by FXMLLoader

	@FXML // fx:id="tabPaciente5"
	private TableColumn<?, ?> tabStatusEntrada; // Value injected by FXMLLoader

	@FXML
	void handleSubmitButtonAction(ActionEvent event) {

	}

	@FXML // This method is called by the FXMLLoader when initialization is complete
	void initialize() {
		assert btnOk != null : "fx:id=\"btnCadastrar9\" was not injected: check your FXML file 'Paciente.fxml'.";
		assert tabNome != null : "fx:id=\"tabPaciente\" was not injected: check your FXML file 'Paciente.fxml'.";
		assert tabComentario != null : "fx:id=\"tabPaciente0\" was not injected: check your FXML file 'Paciente.fxml'.";
		assert tabNomeHistorico != null : "fx:id=\"tabPaciente1\" was not injected: check your FXML file 'Paciente.fxml'.";
		assert tabData != null : "fx:id=\"tabPaciente2\" was not injected: check your FXML file 'Paciente.fxml'.";
		assert tabStatusEnfermidade != null : "fx:id=\"tabPaciente3\" was not injected: check your FXML file 'Paciente.fxml'.";
		assert tabDataSaida != null : "fx:id=\"tabPaciente4\" was not injected: check your FXML file 'Paciente.fxml'.";
		assert tabStatusEntrada != null : "fx:id=\"tabPaciente5\" was not injected: check your FXML file 'Paciente.fxml'.";

	}
}
