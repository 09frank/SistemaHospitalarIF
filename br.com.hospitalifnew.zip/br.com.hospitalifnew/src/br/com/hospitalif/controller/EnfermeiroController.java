/**
 * Sample Skeleton for 'Enfermeiro.fxml' Controller Class
 */

package br.com.hospitalif.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class EnfermeiroController {

	@FXML // ResourceBundle that was given to the FXMLLoader
	private ResourceBundle resources;

	@FXML // URL location of the FXML file that was given to the FXMLLoader
	private URL location;

	@FXML // fx:id="btnCadastrar9"
	private Button btnCadastrar9; // Value injected by FXMLLoader

	@FXML
	void handleSubmitButtonAction(ActionEvent event) throws IOException {
		if (btnCadastrar9.getText().equals("")) {
			Stage stage = (Stage) btnCadastrar9.getScene().getWindow();
			Parent root = FXMLLoader.load(getClass().getResource("../view/Enfermeiro.fxml"));
			Scene scene = new Scene(root);
			// scene.getStylesheets().add(getClass().getResource("/css/estilo.css").
			// toExternalForm()); stage.setTitle("Alerta: ERRO!"); stage.setScene(scene);
			stage.show();
		} else {
			Stage stage = (Stage) btnCadastrar9.getScene().getWindow();
			Parent root = FXMLLoader.load(getClass().getResource("../view/Enfermeiro.fxml"));
			Scene scene = new Scene(root);
			// scene.getStylesheets().add(getClass().getResource("/css/estilo.css").
			// toExternalForm()); stage.setTitle("Alerta: Sucesso!"); stage.setScene(scene);
			stage.show();
		}

	}

	@FXML // This method is called by the FXMLLoader when initialization is complete
	void initialize() {
		assert btnCadastrar9 != null : "fx:id=\"btnCadastrar9\" was not injected: check your FXML file 'Enfermeiro.fxml'.";

	}
}
