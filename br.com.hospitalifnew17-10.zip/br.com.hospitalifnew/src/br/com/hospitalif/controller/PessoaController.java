/**
 * Sample Skeleton for 'Pessoa.fxml' Controller Class
 */

package br.com.hospitalif.controller;

import com.gluonhq.charm.glisten.control.TextField;

import br.com.hospitalif.dao.AtendimentoDAO;
import br.com.hospitalif.model.Atendimento;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class PessoaController {

    @FXML // ResourceBundle that was given to the FXMLLoader
    private ResourceBundle resources;

    @FXML // URL location of the FXML file that was given to the FXMLLoader
    private URL location;

    @FXML // fx:id="txtPessoa5"
    private Button txtPessoa5; // Value injected by FXMLLoader

    @FXML // fx:id="txtPessoa"
    private TextField txtPessoa; // Value injected by FXMLLoader

    @FXML // fx:id="txtPessoa1"
    private TextField txtPessoa1; // Value injected by FXMLLoader

    @FXML // fx:id="txtPessoa3"
    private TextField txtPessoa3; // Value injected by FXMLLoader

    @FXML // fx:id="txtPessoa0"
    private TextField txtPessoa0; // Value injected by FXMLLoader

    @FXML // fx:id="txtPessoa2"
    private TextField txtPessoa2; // Value injected by FXMLLoader

    @FXML // fx:id="txtPessoa4"
    private TextField txtPessoa4; // Value injected by FXMLLoader

    @FXML
    void handleSubmitButtonAction(ActionEvent event) throws IOException{

    	if (txtPessoa5.getText().equals("")) {
			Stage stage = (Stage) txtPessoa5.getScene().getWindow();
			Parent root = FXMLLoader.load(getClass().getResource("../view/Pessoa.fxml"));
			Scene scene = new Scene(root);
			// scene.getStylesheets().add(getClass().getResource("/css/estilo.css").
			// toExternalForm()); stage.setTitle("Alerta: ERRO!"); stage.setScene(scene);
			stage.show();
		} else {
			Atendimento en = new Atendimento();
			en.setNome(Float.parseFloat((txtPessoa.getText())));
			en.setCpf(Float.parseFloat((String)(txtPessoa1.getText())));
			en.setIdade(Float.parseFloat((String) (txtPessoa3.getText())));
			en.setTipoSanguineo(Float.parseFloat((String)(txtPessoa0.getText())));
			en.setSexo(Float.parseFloat((String)(txtPessoa2.getText())));
			en.setStatusdaPessoa((txtPessoa4.getText()));
			

			// en.setData(Date.parseDate()String(txtAtendimento1.getDate())));

			PessoaDAO efdaoe = new PessoaDAO();
			efdaoe.inserir(en);

			Stage stage = (Stage) txtPessoa5.getScene().getWindow();
			Parent root = FXMLLoader.load(getClass().getResource("../view/Pessoa.fxml"));
			Scene scene = new Scene(root);
			// scene.getStylesheets().add(getClass().getResource("/css/estilo.css").
			// toExternalForm()); stage.setTitle("Alerta: Sucesso!"); stage.setScene(scene);
			stage.show();
		}

    @FXML // This method is called by the FXMLLoader when initialization is complete
    void initialize() {
        assert txtPessoa5 != null : "fx:id=\"txtPessoa5\" was not injected: check your FXML file 'Pessoa.fxml'.";
        assert txtPessoa != null : "fx:id=\"txtPessoa\" was not injected: check your FXML file 'Pessoa.fxml'.";
        assert txtPessoa1 != null : "fx:id=\"txtPessoa1\" was not injected: check your FXML file 'Pessoa.fxml'.";
        assert txtPessoa3 != null : "fx:id=\"txtPessoa3\" was not injected: check your FXML file 'Pessoa.fxml'.";
        assert txtPessoa0 != null : "fx:id=\"txtPessoa0\" was not injected: check your FXML file 'Pessoa.fxml'.";
        assert txtPessoa2 != null : "fx:id=\"txtPessoa2\" was not injected: check your FXML file 'Pessoa.fxml'.";
        assert txtPessoa4 != null : "fx:id=\"txtPessoa4\" was not injected: check your FXML file 'Pessoa.fxml'.";

    }
}
