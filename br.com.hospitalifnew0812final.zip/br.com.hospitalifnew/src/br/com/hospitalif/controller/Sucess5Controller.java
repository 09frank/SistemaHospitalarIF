package br.com.hospitalif.controller;

public class Sucess5Controller {

}
