package br.com.hospitalif.controller;

public class Sucess4Controller {

}
