
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Sample Skeleton for 'cadartro funcionario.fxml' Controller Class
 */

package br.com.hospitalif.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import br.com.hospitalif.util.Rotas;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class AtendenteController {

	@FXML // ResourceBundle that was given to the FXMLLoader
	private ResourceBundle resources;

	@FXML // URL location of the FXML file that was given to the FXMLLoader
	private URL location;

	@FXML // fx:id="btnAtendente"
	private Button btnAtendente; // Value injected by FXMLLoader

	@FXML // fx:id="idVoltar"
	private Button idVoltar; // Value injected by FXMLLoader

	@FXML
	void ir(ActionEvent event) {
		Stage stage = (Stage) btnAtendente.getScene().getWindow();
		Parent root = null;
		try {
			root = FXMLLoader.load(getClass().getResource(Rotas.PESSOAATE));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource(Rotas.PESSOASCSS).toExternalForm());
		stage.setTitle("Atendente");
		stage.setScene(scene);
		stage.show();
	}

	@FXML
	void voltar(ActionEvent event) {

		Stage stage = (Stage) idVoltar.getScene().getWindow();
		Parent root = null;
		try {
			root = FXMLLoader.load(getClass().getResource(Rotas.HOME));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource(Rotas.HOMECSS).toExternalForm());
		stage.setTitle("Hospital IF");
		stage.setScene(scene);
		stage.show();

	}

	@FXML // This method is called by the FXMLLoader when initialization is complete
	void initialize() {
		assert btnAtendente != null : "fx:id=\"btnAtendente\" was not injected: check your FXML file 'Atendente.fxml'.";
		assert idVoltar != null : "fx:id=\"idVoltar\" was not injected: check your FXML file 'Atendente.fxml'.";

	}
}
