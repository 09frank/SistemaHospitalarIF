/**
 * Sample Skeleton for 'Paciente.fxml' Controller Class
 */

package br.com.hospitalif.controller;

import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;

import br.com.hospitalif.dao.PacienteDAO;
import br.com.hospitalif.model.EnfermidadePessoal;
import br.com.hospitalif.model.Entrada;
import br.com.hospitalif.report.PrintReport;
import br.com.hospitalif.util.Rotas;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import net.sf.jasperreports.engine.JRException;

public class PacienteController {

	@FXML // ResourceBundle that was given to the FXMLLoader
	private ResourceBundle resources;

	@FXML // URL location of the FXML file that was given to the FXMLLoader
	private URL location;

	@FXML // fx:id="btnCadastrar9"
	private Button btnCadastrar9; // Value injected by FXMLLoader

	@FXML // fx:id="tabPaciente"
	private TableView<EnfermidadePessoal> tabPaciente; // Value injected by FXMLLoader

	@FXML // fx:id="idNome0"
	private TableColumn<EnfermidadePessoal, String> idNome0; // Value injected by FXMLLoader

	@FXML // fx:id="tabPaciente0"
	private TableColumn<EnfermidadePessoal, String> tabPaciente0; // Value injected by FXMLLoader

	@FXML // fx:id="tabPaciente1"
	private TableColumn<EnfermidadePessoal, String> tabPaciente1; // Value injected by FXMLLoader

	@FXML // fx:id="tabPaciente2"
	private TableView<Entrada> tabPaciente2; // Value injected by FXMLLoader

	@FXML // fx:id="idNome1"
	private TableColumn<Entrada, String> idNome1; // Value injected by FXMLLoader

	@FXML // fx:id="tabPaciente3"
	private TableColumn<Entrada, Date> tabPaciente3; // Value injected by FXMLLoader

	@FXML // fx:id="tabPaciente4"
	private TableColumn<Entrada, Date> tabPaciente4; // Value injected by FXMLLoader

	@FXML // fx:id="tabPaciente5"
	private TableColumn<Entrada, String> tabPaciente5; // Value injected by FXMLLoader

	@FXML // fx:id="idRelatorio"
	private Button idRelatorio; // Value injected by FXMLLoader

	@FXML
	void handleSubmitButtonAction(ActionEvent event) {

		Stage stage = (Stage) btnCadastrar9.getScene().getWindow();
		Parent root = null;
		try {
			root = FXMLLoader.load(getClass().getResource(Rotas.HOME));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource(Rotas.HOMECSS).toExternalForm());
		stage.setTitle("HOME");
		stage.setScene(scene);
		stage.show();

	}

	public void listaA(URL arg0, ResourceBundle arg1) {
		tabPaciente0.setCellValueFactory(new PropertyValueFactory<>("comentario"));
		tabPaciente1.setCellValueFactory(new PropertyValueFactory<>("statusDeEnfermidade"));

		PacienteDAO paADAO = new PacienteDAO();
		List<EnfermidadePessoal> pacientes0 = paADAO.doenca();

		ObservableList<EnfermidadePessoal> obsp = FXCollections.observableArrayList(pacientes0);

		tabPaciente.setItems(obsp);

	}

	public void listaB(URL arg0, ResourceBundle arg1) {
		tabPaciente3.setCellValueFactory(new PropertyValueFactory<>("dataEntrada"));
		tabPaciente4.setCellValueFactory(new PropertyValueFactory<>("dataSaida"));
		tabPaciente5.setCellValueFactory(new PropertyValueFactory<>("statusEntrada"));

		PacienteDAO paBDAO = new PacienteDAO();
		List<Entrada> pacientes1 = paBDAO.historico();

		ObservableList<Entrada> obsp = FXCollections.observableArrayList(pacientes1);

		tabPaciente2.setItems(obsp);

	}

	@FXML
	void relatorio(ActionEvent event) {
		String relatorio = "Paciente.jrxml";
		try {
			new PrintReport().showReport(relatorio);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JRException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@FXML // This method is called by the FXMLLoader when initialization is complete
	void initialize() {
		assert btnCadastrar9 != null : "fx:id=\"btnCadastrar9\" was not injected: check your FXML file 'Paciente.fxml'.";
		assert tabPaciente != null : "fx:id=\"tabPaciente\" was not injected: check your FXML file 'Paciente.fxml'.";
		assert idNome0 != null : "fx:id=\"idNome0\" was not injected: check your FXML file 'Paciente.fxml'.";
		assert tabPaciente0 != null : "fx:id=\"tabPaciente0\" was not injected: check your FXML file 'Paciente.fxml'.";
		assert tabPaciente1 != null : "fx:id=\"tabPaciente1\" was not injected: check your FXML file 'Paciente.fxml'.";
		assert tabPaciente2 != null : "fx:id=\"tabPaciente2\" was not injected: check your FXML file 'Paciente.fxml'.";
		assert idNome1 != null : "fx:id=\"idNome1\" was not injected: check your FXML file 'Paciente.fxml'.";
		assert tabPaciente3 != null : "fx:id=\"tabPaciente3\" was not injected: check your FXML file 'Paciente.fxml'.";
		assert tabPaciente4 != null : "fx:id=\"tabPaciente4\" was not injected: check your FXML file 'Paciente.fxml'.";
		assert tabPaciente5 != null : "fx:id=\"tabPaciente5\" was not injected: check your FXML file 'Paciente.fxml'.";

	}
}
