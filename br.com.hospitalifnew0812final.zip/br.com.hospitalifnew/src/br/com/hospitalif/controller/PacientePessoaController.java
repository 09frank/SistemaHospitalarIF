/**
 * Sample Skeleton for 'PacientePessoa.fxml' Controller Class
 */

package br.com.hospitalif.controller;

import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.ResourceBundle;

import br.com.hospitalif.dao.PacientePessoaDAO;
import br.com.hospitalif.model.PacientePessoa;
import br.com.hospitalif.util.Rotas;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class PacientePessoaController {

	@FXML // ResourceBundle that was given to the FXMLLoader
	private ResourceBundle resources;

	@FXML // URL location of the FXML file that was given to the FXMLLoader
	private URL location;

	@FXML // fx:id="AreaEdicao"
	private AnchorPane AreaEdicao; // Value injected by FXMLLoader

	@FXML // fx:id="txtNome"
	private TextField txtNome; // Value injected by FXMLLoader

	@FXML // fx:id="txtCpf"
	private TextField txtCpf; // Value injected by FXMLLoader

	@FXML // fx:id="txtIdade"
	private TextField txtIdade; // Value injected by FXMLLoader

	@FXML // fx:id="txtTipoSangue"
	private TextField txtTipoSangue; // Value injected by FXMLLoader

	@FXML // fx:id="txtSexo"
	private TextField txtSexo; // Value injected by FXMLLoader

	@FXML // fx:id="txtStatusPessoa"
	private TextField txtStatusPessoa; // Value injected by FXMLLoader

	@FXML // fx:id="txtComentarioEnfermeiro"
	private TextField txtComentarioEnfermeiro; // Value injected by FXMLLoader

	@FXML // fx:id="txtComentarioMedico"
	private TextField txtComentarioMedico; // Value injected by FXMLLoader

	@FXML // fx:id="txtPeso"
	private TextField txtPeso; // Value injected by FXMLLoader

	@FXML // fx:id="txtAltura"
	private TextField txtAltura; // Value injected by FXMLLoader

	@FXML // fx:id="txtComentario"
	private TextField txtComentario; // Value injected by FXMLLoader

	@FXML // fx:id="txtSituacaoEnfermidade"
	private TextField txtSituacaoEnfermidade; // Value injected by FXMLLoader

	@FXML // fx:id="txtNomeEnfermidade"
	private TextField txtNomeEnfermidade; // Value injected by FXMLLoader

	@FXML // fx:id="txtTipo"
	private TextField txtTipo; // Value injected by FXMLLoader

	@FXML // fx:id="idDData"
	private DatePicker idDData; // Value injected by FXMLLoader

	@FXML // fx:id="txtDescricao"
	private TextField txtDescricao; // Value injected by FXMLLoader

	@FXML // fx:id="txtStatusEntrada"
	private TextField txtStatusEntrada; // Value injected by FXMLLoader

	@FXML // fx:id="idDDataEntrada"
	private DatePicker idDDataEntrada; // Value injected by FXMLLoader

	@FXML // fx:id="idDDataSaida"
	private DatePicker idDDataSaida; // Value injected by FXMLLoader

	@FXML // fx:id="btnDeletar"
	private Button btnDeletar; // Value injected by FXMLLoader

	@FXML // fx:id="idPaciente"
	private TableView<PacientePessoa> idPaciente; // Value injected by FXMLLoader

	@FXML // fx:id="idCNome"
	private TableColumn<PacientePessoa, String> idCNome; // Value injected by FXMLLoader

	@FXML // fx:id="idCCpf"
	private TableColumn<PacientePessoa, String> idCCpf; // Value injected by FXMLLoader

	@FXML // fx:id="idCIdade"
	private TableColumn<PacientePessoa, Integer> idCIdade; // Value injected by FXMLLoader

	@FXML // fx:id="idCTipoSangue"
	private TableColumn<PacientePessoa, String> idCTipoSangue; // Value injected by FXMLLoader

	@FXML // fx:id="idCSexo"
	private TableColumn<PacientePessoa, String> idCSexo; // Value injected by FXMLLoader

	@FXML // fx:id="idCStatusPessoa"
	private TableColumn<PacientePessoa, String> idCStatusPessoa; // Value injected by FXMLLoader

	@FXML // fx:id="idCComentarioEnfermeiro"
	private TableColumn<PacientePessoa, String> idCComentarioEnfermeiro; // Value injected by FXMLLoader

	@FXML // fx:id="idCComentarioMedico"
	private TableColumn<PacientePessoa, String> idCComentarioMedico; // Value injected by FXMLLoader

	@FXML // fx:id="idCPeso"
	private TableColumn<PacientePessoa, Float> idCPeso; // Value injected by FXMLLoader

	@FXML // fx:id="idCAltura"
	private TableColumn<PacientePessoa, Float> idCAltura; // Value injected by FXMLLoader

	@FXML // fx:id="idCData"
	private TableColumn<PacientePessoa, Date> idCData; // Value injected by FXMLLoader

	@FXML // fx:id="idCComentario"
	private TableColumn<PacientePessoa, String> idCComentario; // Value injected by FXMLLoader

	@FXML // fx:id="idCSituacaoEnfermidade"
	private TableColumn<PacientePessoa, String> idCSituacaoEnfermidade; // Value injected by FXMLLoader

	@FXML // fx:id="idCNomeEnfermidade"
	private TableColumn<PacientePessoa, String> idCNomeEnfermidade; // Value injected by FXMLLoader

	@FXML // fx:id="idcTipo"
	private TableColumn<PacientePessoa, String> idcTipo; // Value injected by FXMLLoader

	@FXML // fx:id="idcDescricao"
	private TableColumn<PacientePessoa, String> idcDescricao; // Value injected by FXMLLoader

	@FXML // fx:id="idCDataEntrada"
	private TableColumn<PacientePessoa, Date> idCDataEntrada; // Value injected by FXMLLoader

	@FXML // fx:id="idcDataSaida"
	private TableColumn<PacientePessoa, Date> idcDataSaida; // Value injected by FXMLLoader

	@FXML // fx:id="idCStatusEntrada"
	private TableColumn<PacientePessoa, String> idCStatusEntrada; // Value injected by FXMLLoader

	@FXML // fx:id="btnEditar"
	private Button btnEditar; // Value injected by FXMLLoader

	@FXML // fx:id="btnSalvar"
	private Button btnSalvar; // Value injected by FXMLLoader

	@FXML // fx:id="btnVoltar"
	private Button btnVoltar; // Value injected by FXMLLoader

	@FXML
	void Salvar(ActionEvent event) {
		try {
			AreaEdicao.setVisible(false);
			String nomePessoa = (txtNome.getText());
			String cpf = (txtCpf.getText());
			int idade = Integer.parseInt(txtIdade.getText());
			String tipoSanguineo = (txtTipoSangue.getText());
			String sexo = (txtSexo.getText());
			String statusDePessoa = (txtStatusPessoa.getText());

			String comentarioEnfermeiro = (txtComentarioEnfermeiro.getText());
			String comentarioMedico = (txtComentarioMedico.getText());
			Float peso = Float.parseFloat((String) (txtPeso.getText()));
			Float altura = Float.parseFloat((String) (txtAltura.getText()));
			LocalDate data = idDData.getValue();

			String comentario = (txtComentario.getText());
			String statusDeEnfermidade = (txtSituacaoEnfermidade.getText());

			String nome1 = (txtNomeEnfermidade.getText());
			String tipo = (txtTipo.getText());
			String descricao = (txtDescricao.getText());

			LocalDate dataEntrada = idDDataEntrada.getValue();
			LocalDate dataSaida = idDDataSaida.getValue();
			String statusEntrada = txtStatusEntrada.getPromptText();

			PacientePessoa a = new PacientePessoa();
			PacientePessoaDAO aDAO = new PacientePessoaDAO();
			PacientePessoa getId = (PacientePessoa) idPaciente.getSelectionModel().getSelectedItem();
			a.setIdPessoa(getId.getIdPessoa());
			a.setNome(nomePessoa);
			a.setCpf(cpf);
			a.setIdade(idade);
			a.setTipoSanguineo(tipoSanguineo);
			a.setSexo(sexo);
			a.setStatusDePessoa(statusDePessoa);
			a.setAltura(altura);
			a.setPeso(peso);
			a.setComentarioEnfermeiro(comentarioEnfermeiro);
			a.setComentarioMedico(comentarioMedico);
			a.setData(data);
			a.setComentario(comentario);
			a.setStatusDeEnfermidade(statusDeEnfermidade);
			a.setNome(nome1);
			a.setTipo(tipo);
			a.setDescricao(descricao);
			a.setDataEntrada(dataEntrada);
			a.setDataSaida(dataSaida);
			a.setStatusEntrada(statusEntrada);
			aDAO.update(a);

		} catch (NumberFormatException e1) {
			e1.printStackTrace();
		}
	}

	@FXML
	void editar(ActionEvent event) {
		try {
			AreaEdicao.setVisible(true);
			PacientePessoa a = (PacientePessoa) idPaciente.getSelectionModel().getSelectedItem();

			txtNome.setText(a.getNome());
			txtCpf.setText(a.getCpf());
			txtIdade.setText("" + a.getIdade());
			txtTipoSangue.setText(a.getTipoSanguineo());
			txtSexo.setText(a.getSexo());
			txtStatusPessoa.setText(a.getStatusDePessoa());
			txtComentarioEnfermeiro.setText(a.getComentarioEnfermeiro());
			txtComentarioMedico.setText(a.getComentarioMedico());
			txtPeso.setText("" + a.getPeso());
			txtAltura.setText("" + a.getAltura());
			idDData.setValue(a.getData());
			txtComentario.setText(a.getComentario());
			txtSituacaoEnfermidade.setText(a.getStatusDeEnfermidade());
			txtNomeEnfermidade.setText(a.getNomeEnfermidade());
			txtTipo.setText(a.getTipo());
			txtDescricao.setText(a.getDescricao());
			idDDataEntrada.setValue(a.getDataEntrada());
			idDDataSaida.setValue(a.getDataSaida());

		} catch (NullPointerException e) {
			AreaEdicao.setVisible(false);

		}
	}

	@FXML
	void excluir(ActionEvent event) throws SQLException {
		PacientePessoa a = (PacientePessoa) idPaciente.getSelectionModel().getSelectedItem();
		System.out.println(a.getIdPessoa());
		PacientePessoaDAO adao = new PacientePessoaDAO();
		adao.delete(a.getIdPessoa());
		adao.delete(a.getIdAtendimento());
		adao.delete(a.getIdEnfermidadePessoal());
		adao.delete(a.getIdEnfermidade());
		adao.delete(a.getIdEntrada());

	}

	@FXML
	void voltar(ActionEvent event) throws IOException {

		Stage stage = (Stage) btnVoltar.getScene().getWindow();
		Parent root = null;
		try {
			root = FXMLLoader.load(getClass().getResource(Rotas.HOME));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource(Rotas.HOMECSS).toExternalForm());
		stage.setTitle("Hospital IF");
		stage.setScene(scene);
		stage.show();

	}

	public void initialize(URL arg0, ResourceBundle arg1) {
		idCNome.setCellValueFactory(new PropertyValueFactory<>("nome"));
		idCCpf.setCellValueFactory(new PropertyValueFactory<>("cpf"));
		idCIdade.setCellValueFactory(new PropertyValueFactory<>("idade"));
		idCTipoSangue.setCellValueFactory(new PropertyValueFactory<>("tipoSangue"));
		idCSexo.setCellValueFactory(new PropertyValueFactory<>("sexo"));
		idCStatusPessoa.setCellValueFactory(new PropertyValueFactory<>("statusDePessoa"));
		idCComentarioEnfermeiro.setCellValueFactory(new PropertyValueFactory<>("comentarioEnfermeiro"));
		idCComentarioMedico.setCellValueFactory(new PropertyValueFactory<>("comentarioMedico"));
		idCPeso.setCellValueFactory(new PropertyValueFactory<>("peso"));
		idCAltura.setCellValueFactory(new PropertyValueFactory<>("altura"));
		idCData.setCellValueFactory(new PropertyValueFactory<>("data"));
		idCComentario.setCellValueFactory(new PropertyValueFactory<>("comentario"));
		idCSituacaoEnfermidade.setCellValueFactory(new PropertyValueFactory<>("SituacaoEnfermidade"));
		idCNomeEnfermidade.setCellValueFactory(new PropertyValueFactory<>("nomeEnfermidade"));
		idcTipo.setCellValueFactory(new PropertyValueFactory<>("tipo"));
		idcDescricao.setCellValueFactory(new PropertyValueFactory<>("descricao"));
		idCDataEntrada.setCellValueFactory(new PropertyValueFactory<>("dataEntrada"));
		idcDataSaida.setCellValueFactory(new PropertyValueFactory<>("dataSaida"));
		idCStatusEntrada.setCellValueFactory(new PropertyValueFactory<>("statusEntrada"));

		PacientePessoaDAO adao = new PacientePessoaDAO();
		List<PacientePessoa> os = adao.read();
		ObservableList<PacientePessoa> itens = FXCollections.observableArrayList(os);
		idPaciente.setItems(itens);
		AreaEdicao.setVisible(false);
	}

	@FXML // This method is called by the FXMLLoader when initialization is complete
	void initialize() {
		assert AreaEdicao != null : "fx:id=\"AreaEdicao\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert txtNome != null : "fx:id=\"txtNome\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert txtCpf != null : "fx:id=\"txtCpf\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert txtIdade != null : "fx:id=\"txtIdade\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert txtTipoSangue != null : "fx:id=\"txtTipoSangue\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert txtSexo != null : "fx:id=\"txtSexo\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert txtStatusPessoa != null : "fx:id=\"txtStatusPessoa\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert txtComentarioEnfermeiro != null : "fx:id=\"txtComentarioEnfermeiro\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert txtComentarioMedico != null : "fx:id=\"txtComentarioMedico\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert txtPeso != null : "fx:id=\"txtPeso\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert txtAltura != null : "fx:id=\"txtAltura\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert txtComentario != null : "fx:id=\"txtComentario\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert txtSituacaoEnfermidade != null : "fx:id=\"txtSituacaoEnfermidade\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert txtNomeEnfermidade != null : "fx:id=\"txtNomeEnfermidade\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert txtTipo != null : "fx:id=\"txtTipo\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert idDData != null : "fx:id=\"idDData\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert txtDescricao != null : "fx:id=\"txtDescricao\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert txtStatusEntrada != null : "fx:id=\"txtStatusEntrada\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert idDDataEntrada != null : "fx:id=\"idDDataEntrada\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert idDDataSaida != null : "fx:id=\"idDDataSaida\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert btnDeletar != null : "fx:id=\"btnCancelar\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert idPaciente != null : "fx:id=\"idPaciente\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert idCNome != null : "fx:id=\"idCNome\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert idCCpf != null : "fx:id=\"idCCpf\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert idCIdade != null : "fx:id=\"idCIdade\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert idCTipoSangue != null : "fx:id=\"idCTipoSangue\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert idCSexo != null : "fx:id=\"idCSexo\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert idCStatusPessoa != null : "fx:id=\"idCStatusPessoa\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert idCComentarioEnfermeiro != null : "fx:id=\"idCComentarioEnfermeiro\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert idCComentarioMedico != null : "fx:id=\"idCComentarioMedico\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert idCPeso != null : "fx:id=\"idCPeso\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert idCAltura != null : "fx:id=\"idCAltura\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert idCData != null : "fx:id=\"idCData\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert idCComentario != null : "fx:id=\"idCComentario\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert idCSituacaoEnfermidade != null : "fx:id=\"idCSituacaoEnfermidade\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert idCNomeEnfermidade != null : "fx:id=\"idCNomeEnfermidade\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert idcTipo != null : "fx:id=\"idcTipo\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert idcDescricao != null : "fx:id=\"idcDescricao\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert idCDataEntrada != null : "fx:id=\"idCDataEntrada\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert idcDataSaida != null : "fx:id=\"idcDataSaida\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert idCStatusEntrada != null : "fx:id=\"idCStatusEntrada\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert btnEditar != null : "fx:id=\"btnEditar\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert btnSalvar != null : "fx:id=\"btnSalvar\" was not injected: check your FXML file 'PacientePessoa.fxml'.";
		assert btnVoltar != null : "fx:id=\"btnVoltar\" was not injected: check your FXML file 'PacientePessoa.fxml'.";

	}
}
