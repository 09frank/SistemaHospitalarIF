/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * 
 */

package br.com.hospitalif.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.hospitalif.conexao.Conexao;
import br.com.hospitalif.model.FuncionarioPessoa;

public class FuncionarioPessoaDAO {
	/*
	 * public void read(FuncionarioPessoaController fpa) { Conexao conn = new
	 * Conexao(); Connection conexao = conn.getConnection();
	 * System.out.println(conn.getStatus()); String sqlLer =
	 * "select tb_pessoa.nome, tb_funcionariopessoa.* from tb_funcionariopessoa, tb_pessoa group by tb_pessoa.nome ASC"
	 * ; PreparedStatement stmt = null; try { stmt =
	 * conexao.prepareStatement(sqlLer); } catch (SQLException e) { // TODO
	 * Auto-generated catch block e.printStackTrace(); } ResultSet rs = null; try {
	 * rs = stmt.executeQuery(); } catch (SQLException e) { // TODO Auto-generated
	 * catch block e.printStackTrace(); } List<FuncionarioPessoaController>
	 * funcionarioPessoas = new ArrayList<FuncionarioPessoaController>(); try {
	 * while (rs.next()) { FuncionarioPessoaController fpa1 = new
	 * FuncionarioPessoaController(); fpa1.getCargo(); fpa1.getCpf();
	 * funcionarioPessoas.add(fpa1); } } catch (SQLException e) { // TODO
	 * Auto-generated catch block e.printStackTrace(); }
	 * 
	 * }
	 * 
	 * /* public void update(Atendimento a) throws SQLException { Conexao conn = new
	 * Conexao(); Connection conexao = conn.getConnection();
	 * System.out.println(conn.getStatus()); String sqlAtualizar =
	 * "UPDATE Atendimento a set(?,?,?,?,?) where id=(?) "; PreparedStatement stmt =
	 * conexao.prepareStatement(sqlAtualizar);
	 * 
	 * stmt.setString(3, a.getComentarioEnfermeiro()); stmt.setString(4,
	 * a.getComentarioMedico()); stmt.setFloat(2, a.getPeso()); stmt.setFloat(1,
	 * a.getAltura()); stmt.setDate(5, (Date) a.getData());
	 * 
	 * stmt.execute();
	 * 
	 * }
	 * 
	 * public void delete(int id) throws SQLException { Conexao conn = new
	 * Conexao(); Connection conexao = conn.getConnection();
	 * System.out.println(conn.getStatus()); String sqlApagar =
	 * "DELETE from Atendimento where id =(?)"; PreparedStatement stmt =
	 * conexao.prepareStatement(sqlApagar);
	 * 
	 * stmt.setInt(1, id); stmt.execute();
	 * 
	 * }
	 */
	/*
	 * private Connection connection;
	 * 
	 * public Connection getConnection() { return connection; }
	 * 
	 * public void setConnection(Connection connection) { this.connection =
	 * connection; }
	 * 
	 * public boolean inserir(FuncionarioPessoaController funcionarioPessoa) {
	 * String sql =
	 * "INSERT INTO funcionarioPessoas(nome, Login, Senha) VALUES(?,?,?)"; try {
	 * PreparedStatement stmt = connection.prepareStatement(sql); stmt.setString(1,
	 * funcionarioPessoa.getNome()); stmt.setString(2,
	 * funcionarioPessoa.getLogin()); stmt.setString(3,
	 * funcionarioPessoa.getSenha()); stmt.execute(); return true; } catch
	 * (SQLException ex) {
	 * Logger.getLogger(FuncionarioPessoaDAO.class.getName()).log(Level.SEVERE,
	 * null, ex); return false; } }
	 * 
	 * public boolean alterar(FuncionarioPessoaController funcionarioPessoa) {
	 * String sql =
	 * "UPDATE funcionarioPessoas SET nome=?, login=?, senha=? WHERE cdFuncionarioPessoa=?"
	 * ; try { PreparedStatement stmt = connection.prepareStatement(sql);
	 * stmt.setString(1, funcionarioPessoa.getNome()); stmt.setString(2,
	 * funcionarioPessoa.getLogin()); stmt.setString(3,
	 * funcionarioPessoa.getSenha()); stmt.setInt(4,
	 * funcionarioPessoa.getCdFuncionarioPessoa()); stmt.execute(); return true; }
	 * catch (SQLException ex) {
	 * Logger.getLogger(FuncionarioPessoaDAO.class.getName()).log(Level.SEVERE,
	 * null, ex); return false; } }
	 * 
	 * public boolean remover(FuncionarioPessoaController funcionarioPessoa) {
	 * String sql = "DELETE FROM funcionarioPessoas WHERE cdFuncionarioPessoa=?";
	 * try { PreparedStatement stmt = connection.prepareStatement(sql);
	 * stmt.setInt(1, funcionarioPessoa.getCdFuncionarioPessoa()); stmt.execute();
	 * return true; } catch (SQLException ex) {
	 * Logger.getLogger(FuncionarioPessoaDAO.class.getName()).log(Level.SEVERE,
	 * null, ex); return false; } }
	 * 
	 * public List<FuncionarioPessoaController> listar() { String sql =
	 * "SELECT * FROM funcionarioPessoas"; List<FuncionarioPessoaController> retorno
	 * = new ArrayList<>(); try { PreparedStatement stmt =
	 * connection.prepareStatement(sql); ResultSet resultado = stmt.executeQuery();
	 * while (resultado.next()) { FuncionarioPessoaController funcionarioPessoa =
	 * new FuncionarioPessoaController();
	 * funcionarioPessoa.setCdFuncionarioPessoa(resultado.getInt(
	 * "cdFuncionarioPessoa"));
	 * funcionarioPessoa.setNome(resultado.getString("nome"));
	 * funcionarioPessoa.setLogin(resultado.getString("login"));
	 * funcionarioPessoa.setSenha(resultado.getString("senha"));
	 * retorno.add(funcionarioPessoa); } } catch (SQLException ex) {
	 * Logger.getLogger(FuncionarioPessoaDAO.class.getName()).log(Level.SEVERE,
	 * null, ex); } return retorno; }
	 * 
	 * public FuncionarioPessoaController buscar(FuncionarioPessoaController
	 * funcionarioPessoa) { String sql =
	 * "SELECT * FROM funcionarioPessoas WHERE cdFuncionarioPessoa=?";
	 * FuncionarioPessoaController retorno = new FuncionarioPessoaController(); try
	 * { PreparedStatement stmt = connection.prepareStatement(sql); stmt.setInt(1,
	 * funcionarioPessoa.getCdFuncionarioPessoa()); ResultSet resultado =
	 * stmt.executeQuery(); if (resultado.next()) {
	 * funcionarioPessoa.setNome(resultado.getString("nome"));
	 * funcionarioPessoa.setLogin(resultado.getString("login"));
	 * funcionarioPessoa.setSenha(resultado.getString("senha")); retorno =
	 * funcionarioPessoa; } } catch (SQLException ex) {
	 * Logger.getLogger(FuncionarioPessoaDAO.class.getName()).log(Level.SEVERE,
	 * null, ex); } return retorno; }
	 */

	public void create(FuncionarioPessoa fpa) {
		Conexao conn = new Conexao();
		Connection conexao = conn.getConnection();
		System.out.println(conn.getStatus());
		String sqlInsere = "INSERT INTO tb_pessoa VALUES (?,?,?,?,?,?) ";
		PreparedStatement stmt = null;
		try {
			stmt = conexao.prepareStatement(sqlInsere);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt.setString(1, fpa.getNome());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt.setString(2, fpa.getCpf());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt.setInt(3, fpa.getIdade());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt.setString(4, fpa.getTipoSanguineo());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt.setString(5, fpa.getSexo());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt.setString(6, fpa.getStatusDePessoa());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String sqlInsere1 = "INSERT INTO tb_funcionariopessoa VALUES (?,?,?,?,?,?,?) ";
		PreparedStatement stmt1 = null;
		try {
			stmt1 = conexao.prepareStatement(sqlInsere1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			stmt1.setString(1, fpa.getLogin());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt1.setString(2, fpa.getSenha());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt1.setString(3, fpa.getStatusDeUsuario());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt1.setInt(4, fpa.getNumeroDeRegistroEnfermeiro());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt1.setString(5, fpa.getCargo());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt1.setInt(6, fpa.getNumeroDeRegistroMedico());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt1.setString(7, fpa.getEspecialidade());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			stmt.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt1.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void delete(int id) {
		Conexao conn = new Conexao();
		Connection conexao = conn.getConnection();
		System.out.println(conn.getStatus());
		String sqlDeleta = "DELETE from tb_pessoa where idAtendimento =(?)";
		PreparedStatement stmt = null;
		try {
			stmt = conexao.prepareStatement(sqlDeleta);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt.setInt(1, id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String sqlDeleta1 = "DELETE from tb_funcionariopessoa where idAtendimento =(?)";
		PreparedStatement stmt1 = null;
		try {
			stmt1 = conexao.prepareStatement(sqlDeleta1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt1.setInt(1, id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			stmt.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt1.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public List<FuncionarioPessoa> read() {
		List<FuncionarioPessoa> funcionarios = new ArrayList<FuncionarioPessoa>();
		try {
			Conexao conn = new Conexao();
			Connection conexao = conn.getConnection();
			System.out.println(conn.getStatus());
			String sqlLer = "select * from view_funcionariopessoa";
			PreparedStatement stmt = conexao.prepareStatement(sqlLer);
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				FuncionarioPessoa fpa1 = new FuncionarioPessoa();

				fpa1.setNome(rs.getString("nome"));
				fpa1.setCpf(rs.getString("cpf"));
				fpa1.setIdade(rs.getInt("idade"));
				fpa1.setTipoSanguineo(rs.getString("tipoSanguineo"));
				fpa1.setSexo(rs.getString("sexo"));
				fpa1.setStatusDePessoa(rs.getString("statusDePessoa"));
				fpa1.setLogin(rs.getString("login"));
				fpa1.setSenha(rs.getString("senha"));
				fpa1.setStatusDeUsuario(rs.getString("statusDeUsuario"));
				fpa1.setNumeroDeRegistroEnfermeiro(rs.getInt("numeroDeRegistroEnfermeiro"));
				fpa1.setCargo(rs.getString("cargo"));
				fpa1.setNumeroDeRegistroMedico(rs.getInt("numeroDeRegistroMedico"));
				fpa1.setEspecialidade(rs.getString("especialidade"));
				funcionarios.add(fpa1);
			}

		} catch (SQLException e) {
			// TODO: handle exception
		}
		return funcionarios;

	}

	public void update(FuncionarioPessoa fpa0) {
		Conexao conn = new Conexao();
		Connection conexao = conn.getConnection();
		System.out.println(conn.getStatus());
		String sqlEditar = "update tb_pessoa set nome=(?),cpf =(?),idade=(?),tipoSanguineo=(?),sexo=(?),statusDePessoa=(?) where idPessoa=(?)";
		PreparedStatement stmt = null;
		try {
			stmt = conexao.prepareStatement(sqlEditar);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			stmt.setString(1, fpa0.getNome());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt.setString(2, fpa0.getCpf());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt.setInt(3, fpa0.getIdade());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt.setString(4, fpa0.getTipoSanguineo());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt.setString(5, fpa0.getSexo());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt.setString(6, fpa0.getStatusDePessoa());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String sqlEditar1 = "update tb_funcionariopessoa set login=(?),senha =(?),statusDeUsuario=(?),numeroDeRegistroEnfermeiro=(?),cargo=(?),numeroDeRegistroMedico=(?),especialidade=(?) where idFuncionario=(?)";
		PreparedStatement stmt1 = null;
		try {
			stmt1 = conexao.prepareStatement(sqlEditar1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			stmt1.setString(1, fpa0.getLogin());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt1.setString(2, fpa0.getSenha());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt1.setString(3, fpa0.getStatusDeUsuario());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt1.setInt(4, fpa0.getNumeroDeRegistroEnfermeiro());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt1.setString(5, fpa0.getCargo());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt1.setInt(6, fpa0.getNumeroDeRegistroMedico());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt1.setString(7, fpa0.getEspecialidade());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			stmt.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt1.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
