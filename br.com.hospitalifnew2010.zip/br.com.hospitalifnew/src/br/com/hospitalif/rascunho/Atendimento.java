/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * 
 */
package br.com.hospitalif.rascunho;

import java.util.Date;
import java.util.List;

/**
 * @author Frank
 *
 */
public class Atendimento {
	/*
	 * private int idAtendimento; private String comentarioEnfermeiro; private
	 * String comentarioMedico; private float peso; private float altura; private
	 * Date data; private List<EnfermidadePessoal> doenca;
	 * 
	 * /**
	 * 
	 * 
	 * public Atendimento() { // TODO Auto-generated constructor stub }
	 */

}
