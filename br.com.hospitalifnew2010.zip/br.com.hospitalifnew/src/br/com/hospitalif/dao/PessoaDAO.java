/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * 
 */
package br.com.hospitalif.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import br.com.hospitalif.conexao.Conexao;
import br.com.hospitalif.model.Pessoa;

/**
 * @author Frank
 *
 */
public class PessoaDAO {

	public void create(Pessoa p) throws SQLException {
		Conexao conn = new Conexao();
		Connection conexao = conn.getConnection();
		System.out.println(conn.getStatus());
		String sqlInsere = "INSERT INTO tb_pessoa VALUES (?,?,?,?,?,?) ";
		PreparedStatement stmt = conexao.prepareStatement(sqlInsere);

		stmt.setString(1, p.getNome());
		stmt.setString(2, p.getCpf());
		stmt.setInt(3, p.getIdade());
		stmt.setString(4, p.getTipoSanguineo());
		stmt.setString(5, p.getSexo());
		stmt.setString(6, p.getStatusDePessoa());

		stmt.execute();
	}

}
