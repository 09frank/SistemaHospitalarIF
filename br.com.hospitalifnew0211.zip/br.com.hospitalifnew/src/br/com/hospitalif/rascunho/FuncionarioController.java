/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**

 * Sample Skeleton for 'Funcionario.fxml' Controller Class
 */

package br.com.hospitalif.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import br.com.hospitalif.dao.FuncionarioDAO;
import br.com.hospitalif.model.Funcionario;
import br.com.hospitalif.util.Rotas;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * @author Frank
 *
 */
public class FuncionarioController {

	@FXML // ResourceBundle that was given to the FXMLLoader
	private ResourceBundle resources;

	@FXML // URL location of the FXML file that was given to the FXMLLoader
	private URL location;

	@FXML // fx:id="btnCadastrar9"
	private Button btnCadastrar9; // Value injected by FXMLLoader

	@FXML // fx:id="txtFuncionario"
	private TextField txtFuncionario; // Value injected by FXMLLoader

	@FXML // fx:id="txtFuncionario0"
	private TextField txtFuncionario0; // Value injected by FXMLLoader

	@FXML // fx:id="txtFuncionario1"
	private TextField txtFuncionario1; // Value injected by FXMLLoader

	@FXML // fx:id="txtFuncionario2"
	private TextField txtFuncionario2; // Value injected by FXMLLoader

	@FXML
	void handleSubmitButtonAction(ActionEvent event) throws IOException {

		if (txtFuncionario0.getText().equals("")) {
			Stage stage = (Stage) btnCadastrar9.getScene().getWindow();
			Parent root = FXMLLoader.load(getClass().getResource(Rotas.FUNCIONARIO));
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource(Rotas.APP).toExternalForm());
			stage.setTitle("Alerta: ERRO!");
			stage.setScene(scene);
			stage.show();
		} else {
			Funcionario fu = new Funcionario();
			fu.setLogin(txtFuncionario0.getText());
			fu.setSenha(txtFuncionario1.getText());

			FuncionarioDAO efdaof = new FuncionarioDAO();
			efdaof.inserir(fu);

			Stage stage = (Stage) btnCadastrar9.getScene().getWindow();
			Parent root = FXMLLoader.load(getClass().getResource("../view/Home.fxml"));
			Scene scene = new Scene(root);
			/// scene.getStylesheets().add(getClass().getResource("/css/estilo.css").toExternalForm());
			stage.setTitle("Alerta: Sucesso!");
			stage.setScene(scene);
			stage.show();
		}

	}

	@FXML // This method is called by the FXMLLoader when initialization is complete
	void initialize() {
		assert btnCadastrar9 != null : "fx:id=\"btnCadastrar9\" was not injected: check your FXML file 'Funcionario.fxml'.";
		assert txtFuncionario != null : "fx:id=\"txtFuncionario\" was not injected: check your FXML file 'Funcionario.fxml'.";
		assert txtFuncionario0 != null : "fx:id=\"txtFuncionario0\" was not injected: check your FXML file 'Funcionario.fxml'.";
		assert txtFuncionario1 != null : "fx:id=\"txtFuncionario1\" was not injected: check your FXML file 'Funcionario.fxml'.";
		assert txtFuncionario2 != null : "fx:id=\"txtFuncionario2\" was not injected: check your FXML file 'Funcionario.fxml'.";

	}
}
