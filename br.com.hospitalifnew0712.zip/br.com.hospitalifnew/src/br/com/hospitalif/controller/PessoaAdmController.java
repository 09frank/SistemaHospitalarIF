/**
 * Sample Skeleton for 'Pessoa.fxml' Controller Class
 */

package br.com.hospitalif.controller;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

import br.com.hospitalif.dao.PessoaDAO;
import br.com.hospitalif.model.Pessoa;
import br.com.hospitalif.util.Rotas;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class PessoaAdmController {

	@FXML // ResourceBundle that was given to the FXMLLoader
	private ResourceBundle resources;

	@FXML // URL location of the FXML file that was given to the FXMLLoader
	private URL location;

	@FXML // fx:id="txtPessoa5"
	private Button txtPessoa5; // Value injected by FXMLLoader

	@FXML // fx:id="txtPessoa"
	private TextField txtPessoa; // Value injected by FXMLLoader

	@FXML // fx:id="txtPessoa1"
	private TextField txtPessoa1; // Value injected by FXMLLoader

	@FXML // fx:id="txtPessoa3"
	private TextField txtPessoa3; // Value injected by FXMLLoader

	@FXML // fx:id="txtPessoa0"
	private TextField txtPessoa0; // Value injected by FXMLLoader

	@FXML // fx:id="txtPessoa2"
	private TextField txtPessoa2; // Value injected by FXMLLoader

	@FXML // fx:id="txtPessoa4"
	private TextField txtPessoa4; // Value injected by FXMLLoader

	@FXML
	void handleSubmitButtonAction(ActionEvent event) throws SQLException {

		if (txtPessoa5.getText().equals("")) {
			Stage stage = (Stage) txtPessoa5.getScene().getWindow();
			Parent root = null;
			try {
				root = FXMLLoader.load(getClass().getResource(Rotas.PESSOAADM));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Scene Scene = new Scene(root);
			Scene.getStylesheets().add(getClass().getResource(Rotas.APP).toExternalForm());
			stage.setTitle("Alerta: ERRO!");
			stage.setScene(Scene);
			stage.show();
		} else {
			Pessoa p = new Pessoa();
			PessoaDAO pD = new PessoaDAO();

			String nome = (txtPessoa.getText());
			String cpf = (txtPessoa1.getText());
			int idade = Integer.parseInt(txtPessoa3.getText());
			String tipoSanguineo = (txtPessoa0.getText());
			String sexo = (txtPessoa2.getText());
			String statusDePessoa = (txtPessoa4.getText());

			p.setNome(nome);
			p.setCpf(cpf);
			p.setIdade(idade);
			p.setTipoSanguineo(tipoSanguineo);
			p.setSexo(sexo);
			p.setStatusDePessoa(statusDePessoa);

			pD.create(p);

			Stage stage = (Stage) txtPessoa5.getScene().getWindow();
			Parent root = null;
			try {
				root = FXMLLoader.load(getClass().getResource(Rotas.FUNCIONARIO));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Scene Scene = new Scene(root);
			Scene.getStylesheets().add(getClass().getResource(Rotas.APP).toExternalForm());
			stage.setTitle("Alerta: Sucesso!");
			stage.setScene(Scene);
			stage.show();

		}

	}

	@FXML // This method is called by the FXMLLoader when initialization is complete
	void initialize() {
		assert txtPessoa5 != null : "fx:id=\"txtPessoa5\" was not injected: check your FXML file 'Pessoa.fxml'.";
		assert txtPessoa != null : "fx:id=\"txtPessoa\" was not injected: check your FXML file 'Pessoa.fxml'.";
		assert txtPessoa1 != null : "fx:id=\"txtPessoa1\" was not injected: check your FXML file 'Pessoa.fxml'.";
		assert txtPessoa3 != null : "fx:id=\"txtPessoa3\" was not injected: check your FXML file 'Pessoa.fxml'.";
		assert txtPessoa0 != null : "fx:id=\"txtPessoa0\" was not injected: check your FXML file 'Pessoa.fxml'.";
		assert txtPessoa2 != null : "fx:id=\"txtPessoa2\" was not injected: check your FXML file 'Pessoa.fxml'.";
		assert txtPessoa4 != null : "fx:id=\"txtPessoa4\" was not injected: check your FXML file 'Pessoa.fxml'.";

	}
}
