/**
 * 
 */
package br.com.hospitalif.rascunho;

/**
 * @author Frank
 *
 */
public class GerentdeDAO extends FuncionarioDAO {

}
