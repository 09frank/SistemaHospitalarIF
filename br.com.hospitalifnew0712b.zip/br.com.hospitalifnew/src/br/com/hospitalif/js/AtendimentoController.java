/**
 * Sample Skeleton for 'Atendimento.fxml' Controller Class
 */

package br.com.hospitalif.js;

import java.awt.TextField;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TextArea;

public class AtendimentoController {

	@FXML // ResourceBundle that was given to the FXMLLoader
	private ResourceBundle resources;

	@FXML // URL location of the FXML file that was given to the FXMLLoader
	private URL location;

	@FXML // fx:id="txtAtendimento7"
	private Button btnAtendimento; // Value injected by FXMLLoader

	@FXML // fx:id="txtAtendimento4"
	private TableColumn<?, ?> tabPainelNome; // Value injected by FXMLLoader

	@FXML // fx:id="txtAtendimento5"
	private TableColumn<?, ?> tabPainelComentario; // Value injected by FXMLLoader

	@FXML // fx:id="txtAtendimento6"
	private TableColumn<?, ?> tabPainelStatus; // Value injected by FXMLLoader

	@FXML // fx:id="txtAtendimento"
	private TextField txtPeso; // Value injected by FXMLLoader

	@FXML // fx:id="txtAtendimento0"
	private TextField txtAltura; // Value injected by FXMLLoader

	@FXML // fx:id="txtAtendimento2"
	private TextArea txtComentarioEnfermeiro; // Value injected by FXMLLoader

	@FXML // fx:id="txtAtendimento3"
	private TextArea txtComentarioMedico; // Value injected by FXMLLoader

	@FXML // fx:id="txtAtendimento1"
	private DatePicker txtData; // Value injected by FXMLLoader

	@FXML
	void handleSubmitButtonAction(ActionEvent event) {

	}

	@FXML // This method is called by the FXMLLoader when initialization is complete
	void initialize() {
		assert btnAtendimento != null : "fx:id=\"txtAtendimento7\" was not injected: check your FXML file 'Atendimento.fxml'.";
		assert tabPainelNome != null : "fx:id=\"tabPainelNome\" was not injected: check your FXML file 'Atendimento.fxml'.";
		assert tabPainelComentario != null : "fx:id=\"txtPainelComentario\" was not injected: check your FXML file 'Atendimento.fxml'.";
		assert tabPainelStatus != null : "fx:id=\"txtPainelStatus\" was not injected: check your FXML file 'Atendimento.fxml'.";
		assert txtPeso != null : "fx:id=\"txtPeso\" was not injected: check your FXML file 'Atendimento.fxml'.";
		assert txtAltura != null : "fx:id=\"txtAltura\" was not injected: check your FXML file 'Atendimento.fxml'.";
		assert txtComentarioEnfermeiro != null : "fx:id=\"txtComentarioEnfermeiro\" was not injected: check your FXML file 'Atendimento.fxml'.";
		assert txtComentarioMedico != null : "fx:id=\"txtComentarioMedico\" was not injected: check your FXML file 'Atendimento.fxml'.";
		assert txtData != null : "fx:id=\"txtData\" was not injected: check your FXML file 'Atendimento.fxml'.";

	}
}

//localdate
