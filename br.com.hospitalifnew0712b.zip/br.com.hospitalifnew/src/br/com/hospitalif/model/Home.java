/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * 
 */

package br.com.hospitalif.model;

public class Home {

	/// Painel Principal (Home) para os bot�es do sistema.

	/**
	 * 
	 */
	public Home() {
		// TODO Auto-generated constructor stub
	}

}
