/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * 
 */

package br.com.hospitalif.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;

import com.sun.javafx.logging.Logger;

import br.com.hospitalif.model.FuncionarioPessoa;

public class FuncionarioPessoaDAO {
	/*
	 * public void read(FuncionarioPessoa fpa) { Conexao conn = new Conexao();
	 * Connection conexao = conn.getConnection();
	 * System.out.println(conn.getStatus()); String sqlLer =
	 * "select tb_pessoa.nome, tb_funcionariopessoa.* from tb_funcionariopessoa, tb_pessoa group by tb_pessoa.nome ASC"
	 * ; PreparedStatement stmt = null; try { stmt =
	 * conexao.prepareStatement(sqlLer); } catch (SQLException e) { // TODO
	 * Auto-generated catch block e.printStackTrace(); } ResultSet rs = null; try {
	 * rs = stmt.executeQuery(); } catch (SQLException e) { // TODO Auto-generated
	 * catch block e.printStackTrace(); } List<FuncionarioPessoa> funcionarioPessoas
	 * = new ArrayList<FuncionarioPessoa>(); try { while (rs.next()) {
	 * FuncionarioPessoa fpa1 = new FuncionarioPessoa(); fpa1.getCargo();
	 * fpa1.getCpf(); funcionarioPessoas.add(fpa1); } } catch (SQLException e) { //
	 * TODO Auto-generated catch block e.printStackTrace(); }
	 * 
	 * }
	 * 
	 * /* public void update(Atendimento a) throws SQLException { Conexao conn = new
	 * Conexao(); Connection conexao = conn.getConnection();
	 * System.out.println(conn.getStatus()); String sqlAtualizar =
	 * "UPDATE Atendimento a set(?,?,?,?,?) where id=(?) "; PreparedStatement stmt =
	 * conexao.prepareStatement(sqlAtualizar);
	 * 
	 * stmt.setString(3, a.getComentarioEnfermeiro()); stmt.setString(4,
	 * a.getComentarioMedico()); stmt.setFloat(2, a.getPeso()); stmt.setFloat(1,
	 * a.getAltura()); stmt.setDate(5, (Date) a.getData());
	 * 
	 * stmt.execute();
	 * 
	 * }
	 * 
	 * public void delete(int id) throws SQLException { Conexao conn = new
	 * Conexao(); Connection conexao = conn.getConnection();
	 * System.out.println(conn.getStatus()); String sqlApagar =
	 * "DELETE from Atendimento where id =(?)"; PreparedStatement stmt =
	 * conexao.prepareStatement(sqlApagar);
	 * 
	 * stmt.setInt(1, id); stmt.execute();
	 * 
	 * }
	 */

	private Connection connection;

	public Connection getConnection() {
		return connection;
	}

	public void setConnection(Connection connection) {
		this.connection = connection;
	}

	public boolean inserir(FuncionarioPessoa funcionarioPessoa) {
		String sql = "INSERT INTO funcionarioPessoas(nome, Login, Senha) VALUES(?,?,?)";
		try {
			PreparedStatement stmt = connection.prepareStatement(sql);
			stmt.setString(1, funcionarioPessoa.getNome());
			stmt.setString(2, funcionarioPessoa.getLogin());
			stmt.setString(3, funcionarioPessoa.getSenha());
			stmt.execute();
			return true;
		} catch (SQLException ex) {
			Logger.getLogger(FuncionarioPessoaDAO.class.getName()).log(Level.SEVERE, null, ex);
			return false;
		}
	}

	public boolean alterar(FuncionarioPessoa funcionarioPessoa) {
		String sql = "UPDATE funcionarioPessoas SET nome=?, login=?, senha=? WHERE cdFuncionarioPessoa=?";
		try {
			PreparedStatement stmt = connection.prepareStatement(sql);
			stmt.setString(1, funcionarioPessoa.getNome());
			stmt.setString(2, funcionarioPessoa.getLogin());
			stmt.setString(3, funcionarioPessoa.getSenha());
			stmt.setInt(4, funcionarioPessoa.getCdFuncionarioPessoa());
			stmt.execute();
			return true;
		} catch (SQLException ex) {
			Logger.getLogger(FuncionarioPessoaDAO.class.getName()).log(Level.SEVERE, null, ex);
			return false;
		}
	}

	public boolean remover(FuncionarioPessoa funcionarioPessoa) {
		String sql = "DELETE FROM funcionarioPessoas WHERE cdFuncionarioPessoa=?";
		try {
			PreparedStatement stmt = connection.prepareStatement(sql);
			stmt.setInt(1, funcionarioPessoa.getCdFuncionarioPessoa());
			stmt.execute();
			return true;
		} catch (SQLException ex) {
			Logger.getLogger(FuncionarioPessoaDAO.class.getName()).log(Level.SEVERE, null, ex);
			return false;
		}
	}

	public List<FuncionarioPessoa> listar() {
		String sql = "SELECT * FROM funcionarioPessoas";
		List<FuncionarioPessoa> retorno = new ArrayList<>();
		try {
			PreparedStatement stmt = connection.prepareStatement(sql);
			ResultSet resultado = stmt.executeQuery();
			while (resultado.next()) {
				FuncionarioPessoa funcionarioPessoa = new FuncionarioPessoa();
				funcionarioPessoa.setCdFuncionarioPessoa(resultado.getInt("cdFuncionarioPessoa"));
				funcionarioPessoa.setNome(resultado.getString("nome"));
				funcionarioPessoa.setLogin(resultado.getString("login"));
				funcionarioPessoa.setSenha(resultado.getString("senha"));
				retorno.add(funcionarioPessoa);
			}
		} catch (SQLException ex) {
			Logger.getLogger(FuncionarioPessoaDAO.class.getName()).log(Level.SEVERE, null, ex);
		}
		return retorno;
	}

	public FuncionarioPessoa buscar(FuncionarioPessoa funcionarioPessoa) {
		String sql = "SELECT * FROM funcionarioPessoas WHERE cdFuncionarioPessoa=?";
		FuncionarioPessoa retorno = new FuncionarioPessoa();
		try {
			PreparedStatement stmt = connection.prepareStatement(sql);
			stmt.setInt(1, funcionarioPessoa.getCdFuncionarioPessoa());
			ResultSet resultado = stmt.executeQuery();
			if (resultado.next()) {
				funcionarioPessoa.setNome(resultado.getString("nome"));
				funcionarioPessoa.setLogin(resultado.getString("login"));
				funcionarioPessoa.setSenha(resultado.getString("senha"));
				retorno = funcionarioPessoa;
			}
		} catch (SQLException ex) {
			Logger.getLogger(FuncionarioPessoaDAO.class.getName()).log(Level.SEVERE, null, ex);
		}
		return retorno;
	}

}
