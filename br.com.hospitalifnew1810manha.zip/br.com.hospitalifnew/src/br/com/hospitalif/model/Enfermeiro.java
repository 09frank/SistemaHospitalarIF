/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * 
 */

package br.com.hospitalif.model;

/**
 * @author Frank
 *
 */
public class Enfermeiro extends Funcionario {

	private int numeroDeRegistroEnfermeiro;

	/**
	 * 
	 */
	public Enfermeiro() {

		// TODO Auto-generated constructor stub
	}

	/**
	 * @return the numeroDeRegistroEnfermeiro
	 */
	public int getNumeroDeRegistroEnfermeiro() {
		return numeroDeRegistroEnfermeiro;
	}

	/**
	 * @param numeroDeRegistroEnfermeiro the numeroDeRegistroEnfermeiro to set
	 */
	public void setNumeroDeRegistroEnfermeiro(int numeroDeRegistroEnfermeiro) {
		this.numeroDeRegistroEnfermeiro = numeroDeRegistroEnfermeiro;
	}

}
