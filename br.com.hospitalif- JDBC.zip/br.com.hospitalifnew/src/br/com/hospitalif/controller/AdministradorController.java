/**
 * Sample Skeleton for 'Administrador.fxml' Controller Class
 */

package br.com.hospitalif.controller;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class AdministradorController {

	@FXML // ResourceBundle that was given to the FXMLLoader
	private ResourceBundle resources;

	@FXML // URL location of the FXML file that was given to the FXMLLoader
	private URL location;

	@FXML // fx:id="btnFuncionario"
	private Button btnFuncionario; // Value injected by FXMLLoader

	@FXML
	void ir(ActionEvent event) {

	}

	@FXML // This method is called by the FXMLLoader when initialization is complete
	void initialize() {
		assert btnFuncionario != null : "fx:id=\"btnFuncionario\" was not injected: check your FXML file 'Administrador.fxml'.";

	}
}
