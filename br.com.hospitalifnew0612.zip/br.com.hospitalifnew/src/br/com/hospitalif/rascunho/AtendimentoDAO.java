/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * 
 */
package br.com.hospitalif.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.hospitalif.conexao.Conexao;
import br.com.hospitalif.model.Atendimento;

/**
 * @author Frank
 *
 */
public class AtendimentoDAO {

	public void create(Atendimento a) throws SQLException {
		Conexao conn = new Conexao();
		Connection conexao = conn.getConnection();
		System.out.println(conn.getStatus());
		String sqlInsere = "INSERT INTO tb_atendimento VALUES (?,?,?,?,?) ";
		PreparedStatement stmt = conexao.prepareStatement(sqlInsere);

		stmt.setString(1, a.getComentarioEnfermeiro());
		stmt.setString(2, a.getComentarioMedico());
		stmt.setFloat(3, a.getPeso());
		stmt.setFloat(4, a.getAltura());
		stmt.setString(5, a.getData());

		stmt.execute();
	}

	public void lista(Atendimento a) throws SQLException {
		Conexao conn = new Conexao();
		Connection conexao = conn.getConnection();
		System.out.println(conn.getStatus());
		String sqlInsere = "select tb_pessoa.nome, tb_enfermidadepessoal.comentario, tb_enfermidadepessoal.statusDeEnfermidade from tb_enfermidadepessoal, tb_paciente, tb_pessoa order by tb_pessoa.nome";
		PreparedStatement stmt = conexao.prepareStatement(sqlInsere);
		ResultSet rs = stmt.executeQuery();
		List<Atendimento> atendimentos = new ArrayList<Atendimento>();
		while (rs.next()) {
			Atendimento a1 = new Atendimento();
			a1.getComentarioEnfermeiro();
			a1.getComentarioMedico();
			atendimentos.add(a1);
		}

	}

}
