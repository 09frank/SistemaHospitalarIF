/**
 * Sample Skeleton for 'EnfermidadePessoal.fxml' Controller Class
 */

package br.com.hospitalif.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import br.com.hospitalif.dao.EnfermidadePessoalDAO;
import br.com.hospitalif.model.EnfermidadePessoal;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class EnfermidadePessoalController {

    @FXML // ResourceBundle that was given to the FXMLLoader
    private ResourceBundle resources;

    @FXML // URL location of the FXML file that was given to the FXMLLoader
    private URL location;

    @FXML // fx:id="btnEnfermidadePessoal"
    private Button btnEnfermidadePessoal; // Value injected by FXMLLoader

    @FXML // fx:id="txtEnfermidadePessoal0"
    private TextField txtEnfermidadePessoal0; // Value injected by FXMLLoader

    @FXML // fx:id="txtEnfermidadePessoal1"
    private TextField txtEnfermidadePessoal1; // Value injected by FXMLLoader

    @FXML
    void handleSubmitButtonAction(ActionEvent event) throws IOException {
    	if (btnEnfermidadePessoal.getText().equals("")) { Stage stage = (Stage)
    			btnEnfermidadePessoal.getScene().getWindow(); Parent root =
				  FXMLLoader.load(getClass().getResource("../view/EnfermidadePessoal.fxml")); Scene scene =
				  new Scene(root);
				  //scene.getStylesheets().add(getClass().getResource("/css/estilo.css").
				  //toExternalForm()); stage.setTitle("Alerta: ERRO!"); stage.setScene(scene);
				  stage.show();
						  } else { EnfermidadePessoal en = new EnfermidadePessoal();
				 
				  en.setStatusDeEnfermidade(txtEnfermidadePessoal0.getText());
				  en.setComentario(txtEnfermidadePessoal0.getText());
				  
				  
				 
				  EnfermidadePessoalDAO efdaoe = new EnfermidadePessoalDAO(); 
				  efdaoe.inserir(en);
				  
				  Stage stage = (Stage) btnEnfermidadePessoal.getScene().getWindow(); Parent root =
				  FXMLLoader.load(getClass().getResource("../view/EnfermidadePessoal.fxml")); Scene scene =
				  new Scene(root);
				  //scene.getStylesheets().add(getClass().getResource("/css/estilo.css").
				  //toExternalForm()); stage.setTitle("Alerta: Sucesso!"); stage.setScene(scene);
				  stage.show(); }

	}
    

    @FXML // This method is called by the FXMLLoader when initialization is complete
    void initialize() {
        assert btnEnfermidadePessoal != null : "fx:id=\"btnEnfermidadePessoal\" was not injected: check your FXML file 'EnfermidadePessoal.fxml'.";
        assert txtEnfermidadePessoal0 != null : "fx:id=\"txtEnfermidadePessoal0\" was not injected: check your FXML file 'EnfermidadePessoal.fxml'.";
        assert txtEnfermidadePessoal1 != null : "fx:id=\"txtEnfermidadePessoal1\" was not injected: check your FXML file 'EnfermidadePessoal.fxml'.";

    }
}
